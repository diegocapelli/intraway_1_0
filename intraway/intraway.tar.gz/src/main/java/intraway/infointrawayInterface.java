package intraway;

import java.util.List;

import entity.InfoIntraway;



public interface infointrawayInterface {
	public List<InfoIntraway> findAll();
	public void save(InfoIntraway usuario);

}
