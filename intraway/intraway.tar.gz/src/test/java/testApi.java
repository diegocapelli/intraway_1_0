import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import controller.IntrawayController;
import entity.InfoIntraway;



@RunWith(SpringRunner.class)
@WebMvcTest
@SpringBootTest(classes = { InfoIntraway.class,IntrawayController.class })
public class testApi {
	
	@Autowired
    private MockMvc mvc;
	
	@SuppressWarnings("deprecation")
	@Test
	public void testApi() throws Exception {
		
		MvcResult mvc2 =mvc.perform(get("/api/fizzbuzz/1/15")
			      .contentType(MediaType.APPLICATION_JSON))
			      .andExpect(status().isOk())
			      .andReturn();
		//final  IntrawayController multiplos ;
		InfoIntraway multiplo =((IntrawayController) mvc2).saveById(1,15);
		
		InfoIntraway result = new InfoIntraway("001","Se encontraron Multiplos de 3 y 5", "1,2,Fizz,4,Buzz,Fizz,7,8,Fizz,Buzz,11,Fizz,13,14,FizzBuzz");
		assertThat(multiplo).equals(result);
		
		
	}
	
	
	

}
